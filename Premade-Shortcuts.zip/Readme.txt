These shortcuts are examples of how you can use ShortcutArgs.

LoadFile - This will read any file you give it and execute it with Invoke-Expression,
	 the file you're parsing can be in any format as long as the code inside
	 is written as you want it to be input into powershell.